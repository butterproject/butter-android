var Streamer = require('./');
var fs = require('fs');

var streamer = new Streamer(
	"<stream_url>",
	{
		progressInterval: 200,
		buffer: 10 * 1024 * 1024,
		port: 9999,
		tmp: '<directory>/',
		torrent: {
			tmp: '<directory>/'
		}
	}
);

var onProgress = function(progress) {
	fs.writeFile( "<directory>/status.json", JSON.stringify(progress), function(err) {
		if(err) {
	        console.log(err);
	    }
	});
}

var onReady = function(data) {
	fs.writeFile( "<directory>/streamer.json", JSON.stringify(data.streamUrl), function(err) {
		if(err) {
	        console.log(err);
	    }
	});

    console.log("Binding to " + data.streamUrl);
}

streamer.on('progress', onProgress);
streamer.on('ready', onReady);